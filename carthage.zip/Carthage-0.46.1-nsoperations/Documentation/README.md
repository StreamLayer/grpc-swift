This folder contains extended documentation for using Carthage, beyond the README and the `carthage help` command.
