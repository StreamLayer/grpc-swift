* carthage install method: [ ] .pkg, [ ] homebrew, [ ] source
* `which carthage`:
* `carthage version`: 
* `xcodebuild -version`: 
* Are you using `--no-build`? 
* Are you using `--no-use-binaries`? 
* Are you using `--use-submodules`? 
* Are you using `--cache-builds`? 
* Are you using `--new-resolver`? 

**Cartfile**
```
<YOUR CARTFILE>
```

**Carthage Output**
```
<OUTPUT>
```

**Actual outcome**
Carthage did or did not ...

**Expected outcome**
Carthage should ...
