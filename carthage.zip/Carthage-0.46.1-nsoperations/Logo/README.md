This beautiful logo was generously contributed by Reda Lemeden ([@kaishin](https://github.com/kaishin)). Many thanks! :heart:
